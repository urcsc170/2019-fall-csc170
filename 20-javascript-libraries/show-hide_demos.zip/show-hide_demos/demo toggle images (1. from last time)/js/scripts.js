var toggle_button = document.getElementById("toggler");
var toggle_element = document.getElementById("peek-a-boo");

toggle_element.style.display = 'inline';

function toggleElement(e) { 
	if (e.style.display == 'inline') {
		e.style.display = 'none'
	} 		
	else {
		e.style.display = 'inline'
	}
}; 

toggle_button.addEventListener("click", function(){
	toggleElement(toggle_element)
});
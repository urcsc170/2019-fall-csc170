$( "#toggler" ).click(function() {
	$("#peek-a-boo").toggle("slow");
});